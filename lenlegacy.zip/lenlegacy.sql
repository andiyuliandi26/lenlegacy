-- --------------------------------------------------------
-- Host:                         localhost
-- Server version:               5.7.16-log - MySQL Community Server (GPL)
-- Server OS:                    Win64
-- HeidiSQL Version:             10.1.0.5464
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;


-- Dumping database structure for lenlegacy
CREATE DATABASE IF NOT EXISTS `lenlegacy` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `lenlegacy`;

-- Dumping structure for table lenlegacy.gamedetails
CREATE TABLE IF NOT EXISTS `gamedetails` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `gameid` int(11) DEFAULT NULL,
  `playerid` int(11) DEFAULT NULL,
  `heroid` int(11) DEFAULT NULL,
  `team` varchar(1) DEFAULT NULL,
  `herodamage` int(11) DEFAULT NULL,
  `herodamagepersentage` int(11) DEFAULT NULL,
  `turretdamage` int(11) DEFAULT NULL,
  `turretdamagepersentage` int(11) DEFAULT NULL,
  `damagetaken` int(11) DEFAULT NULL,
  `damagetakenpersentage` int(11) DEFAULT NULL,
  `kill` int(11) DEFAULT NULL,
  `death` int(11) DEFAULT NULL,
  `assist` int(11) DEFAULT NULL,
  `gold` varchar(45) DEFAULT NULL,
  `rating` decimal(1,0) DEFAULT NULL,
  `medal` varchar(45) DEFAULT NULL,
  `isvictory` tinyint(1) DEFAULT NULL,
  `ismvpwinning` tinyint(1) DEFAULT NULL,
  `ismvplose` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `playerid_idx` (`playerid`),
  KEY `gameid_idx` (`gameid`),
  KEY `heroid_idx` (`heroid`),
  CONSTRAINT `gameid` FOREIGN KEY (`gameid`) REFERENCES `games` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `heroid` FOREIGN KEY (`heroid`) REFERENCES `hero` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `playerid` FOREIGN KEY (`playerid`) REFERENCES `player` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Dumping data for table lenlegacy.gamedetails: ~0 rows (approximately)
/*!40000 ALTER TABLE `gamedetails` DISABLE KEYS */;
/*!40000 ALTER TABLE `gamedetails` ENABLE KEYS */;

-- Dumping structure for table lenlegacy.games
CREATE TABLE IF NOT EXISTS `games` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `gamename` varchar(100) DEFAULT NULL,
  `gamedate` datetime NOT NULL,
  `seasonid` int(11) NOT NULL,
  `gameduration` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  CONSTRAINT `gameseason` FOREIGN KEY (`id`) REFERENCES `season` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Dumping data for table lenlegacy.games: ~0 rows (approximately)
/*!40000 ALTER TABLE `games` DISABLE KEYS */;
/*!40000 ALTER TABLE `games` ENABLE KEYS */;

-- Dumping structure for table lenlegacy.hero
CREATE TABLE IF NOT EXISTS `hero` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `heroname` varchar(45) NOT NULL,
  `durability` int(11) DEFAULT NULL,
  `offense` int(11) DEFAULT NULL,
  `abilityeffect` int(11) DEFAULT NULL,
  `difficulty` int(11) DEFAULT NULL,
  `images` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=83 DEFAULT CHARSET=utf8;

-- Dumping data for table lenlegacy.hero: ~82 rows (approximately)
/*!40000 ALTER TABLE `hero` DISABLE KEYS */;
INSERT INTO `hero` (`id`, `heroname`, `durability`, `offense`, `abilityeffect`, `difficulty`, `images`) VALUES
	(1, 'Terizla', 59, 82, 68, 65, 'https://img.mobilelegends.com/group1/M00/00/8B/Cq2Ixlz-KjGAc-1ZABKAGFpm7BM360.jpg'),
	(2, 'Esmeralda', 65, 65, 76, 45, 'https://img.mobilelegends.com/group1/M00/00/84/Cq2Ixlyh1muAO2A4AACf3Yr5J2k698.jpg'),
	(3, 'Guinevere', 50, 85, 37, 65, 'https://img.mobilelegends.com/group1/M00/00/78/Cq2IxlxuQR6AAtjKAADGZoqzOd4790.jpg'),
	(4, 'Granger', 55, 80, 35, 69, 'https://img.mobilelegends.com/group1/M00/00/85/Cq2Ixly-wu-AX2PDAACZ0yEn14k256.jpg'),
	(5, 'Khufra', 72, 66, 78, 60, 'https://img.mobilelegends.com/group1/M00/00/7D/Cq2IxlyIxEKAH5TZAADN1Ig1Vck078.jpg'),
	(6, 'Badang', 59, 82, 68, 65, 'https://img.mobilelegends.com/group1/M00/00/70/Cq2Ixlw9j-2AHA67AAEHWLRpOI4513.jpg'),
	(7, 'Faramis', 80, 36, 72, 66, 'https://img.mobilelegends.com/group1/M00/00/88/Cq2IxlzmqriAUfUYAACka76WaSs606.jpg'),
	(8, 'Kadita', 84, 40, 56, 66, 'https://img.mobilelegends.com/group1/M00/00/6D/Cq2IxlwYrb-AFA5KAAEgZvgbXvk427.jpg'),
	(9, 'Minsitthar', 50, 75, 65, 40, 'https://img.mobilelegends.com/group1/M00/00/69/Cq2Ixlv0FRCAIF6ZAAD0XEKxZEM139.jpg'),
	(10, 'Harith', 82, 50, 48, 76, 'https://img.mobilelegends.com/group1/M00/00/67/Cq2IxlvhXhqAHSpgAAD50hPhJ_o145.jpg'),
	(11, 'Thamuz', 74, 76, 71, 56, 'https://img.mobilelegends.com/group1/M00/00/5A/Cq2IxlugsBSAHfefAACsFW0bZGk780.jpg'),
	(12, 'Kimmy', 82, 70, 45, 72, 'https://img.mobilelegends.com/group1/M00/00/63/Cq2IxlvQdfKAQs8FAACSno3WYko057.jpg'),
	(13, 'Belerick', 68, 64, 85, 45, 'https://img.mobilelegends.com/group1/M00/00/50/Cq2Ixlt6svSAHVi_AADQiWe7GjU557.jpg'),
	(14, 'Hanzo', 50, 90, 52, 60, 'https://img.mobilelegends.com/group1/M00/00/6A/Cq2IxlwPgJWAa7oEAABdF567lzI080.jpg'),
	(15, 'Lunox', 78, 40, 66, 65, 'https://img.mobilelegends.com/group1/M00/00/58/Cq2IxluPeROAZWp1AAEJAdQijBY162.jpg'),
	(16, 'Leomord', 58, 84, 65, 52, 'https://img.mobilelegends.com/group1/M00/00/5C/Cq2IxluwyL-AQwheAAC9gsGwxIw636.jpg'),
	(17, 'Vale', 88, 40, 46, 65, 'https://img.mobilelegends.com/group1/M00/00/73/Cq2IxlxP8AeAOF3tAADRJnEWlXM371.jpg'),
	(18, 'Claude', 46, 88, 46, 87, 'https://img.mobilelegends.com/group1/M00/00/4C/Cq2IxltpGsCAQ6vVAACafm-dqsM999.jpg'),
	(19, 'Aldous', 58, 84, 82, 70, 'https://img.mobilelegends.com/group1/M00/00/48/Cq2IxltWy_SAWU4TAACfTAA7dJk424.jpg'),
	(20, 'Selena', 84, 56, 49, 75, 'https://img.mobilelegends.com/group1/M00/00/3F/Cq2IxltEUuCAIgA9AACYGy-0dPc974.jpg'),
	(21, 'Kaja', 80, 49, 75, 60, 'https://img.mobilelegends.com/group1/M00/00/30/Cq2Ixlsor7qANjpkAACpokGW7U4672.jpg'),
	(22, 'Chang\\\'e', 92, 40, 42, 70, 'https://img.mobilelegends.com/group1/M00/00/22/Cq2IxlsMx2WADkO-AADUOFE6YCU843.jpg'),
	(23, 'Hanabi', 52, 90, 50, 65, 'https://img.mobilelegends.com/group1/M00/00/09/Cq2IxlrVkbaAF-E-AAHD5dxcXFg3574905'),
	(24, 'Uranus', 82, 34, 85, 45, 'https://img.mobilelegends.com/group1/M00/00/11/Cq2IxlrxIumAcrKRAAGy0wBvcZc616.jpg'),
	(25, 'Martis', 59, 82, 68, 56, 'https://img.mobilelegends.com/group1/M00/00/05/Cq2Ixlq6ESWAIaeGAAG5-YfdANo3395863'),
	(26, 'Valir', 88, 40, 46, 55, 'https://img.mobilelegends.com/group1/M00/00/04/Cq2IxlqmNA-ASd5OAACia8RAFOE8935592'),
	(27, 'Gusion', 90, 50, 55, 87, 'https://img.mobilelegends.com/group1/M00/00/03/Cq2IxlqP7xeAJX_ZAAF6-aQmyq01091541'),
	(28, 'Angela', 85, 36, 49, 32, 'https://img.mobilelegends.com/group1/M00/00/02/Cq2Ixlp62giAYZ6_AACCfqYsRU40233877'),
	(29, 'Jawhead', 64, 78, 82, 77, 'https://img.mobilelegends.com/group1/M00/00/01/Cq2Ixlpuvg6AZYrUAAB8UvX4GSQ0007229'),
	(30, 'Lesley', 49, 80, 38, 65, 'https://img.mobilelegends.com/group1/M00/00/01/Cq2Ixlp5XSWAS4sTAACF3KBj5bI2024031'),
	(31, 'Pharsa', 90, 40, 53, 75, 'https://img.mobilelegends.com/group1/M00/00/00/Cq2Ixlpll-aAQI1sAAB34j7sXxc3612403'),
	(32, 'Helcurt', 50, 91, 48, 58, 'https://img.mobilelegends.com/group1/M00/00/07/rB_-LVpDtaGAWTYsAACGIUHEBlk2938231'),
	(33, 'Zhask', 92, 43, 50, 38, 'https://img.mobilelegends.com/group1/M00/00/07/rB_-LVpDtYuALm_JAACAVMdzDCg6208200'),
	(34, 'Hylos', 62, 34, 90, 25, 'https://img.mobilelegends.com/group1/M00/00/07/rB_-LVpDtXaARWkdAACdF1TXztY1511830'),
	(35, 'Diggie', 75, 46, 59, 28, 'https://img.mobilelegends.com/group1/M00/00/07/rB_-LVpDtUyAfbEUAACBbLMCtME8399630'),
	(36, 'Lancelot', 40, 96, 50, 68, 'https://img.mobilelegends.com/group1/M00/00/07/rB_-LVpDtTSAEoGpAACG4Dgpl9s2791897'),
	(37, 'Odette', 92, 42, 37, 62, 'https://img.mobilelegends.com/group1/M00/00/07/rB_-LVpDtSCAIsoJAACYTYzUP8I1676804'),
	(38, 'Argus', 72, 85, 46, 46, 'https://img.mobilelegends.com/group1/M00/00/07/rB_-LVpDtQuAGizUAAB60D0MjFo1905917'),
	(39, 'Grock', 60, 54, 81, 45, 'https://img.mobilelegends.com/group1/M00/00/07/rB_-LVpDtPWABoA8AACND_AiFfc2890684'),
	(40, 'Irithel', 44, 80, 42, 66, 'https://img.mobilelegends.com/group1/M00/00/07/rB_-LVpDtNuAShAGAACFrtziHRc2923223'),
	(41, 'Harley', 75, 65, 40, 66, 'https://img.mobilelegends.com/group1/M00/00/07/rB_-LVpDtMSATJUvAACY-VPfC2U7878745'),
	(42, 'Gatotkaca', 70, 49, 92, 70, 'https://img.mobilelegends.com/group1/M00/00/07/rB_-LVpDtK6AaKGkAACtLHzslx08037659'),
	(43, 'Karrie', 46, 88, 31, 87, 'https://img.mobilelegends.com/group1/M00/00/07/rB_-LVpDtJiAIegKAAB1GyoxqLY9646942'),
	(44, 'Roger', 59, 68, 52, 52, 'https://img.mobilelegends.com/group1/M00/00/07/rB_-LVpDtISAOO_NAAByUsK0VHs8632540'),
	(45, 'Vexana', 94, 54, 40, 66, 'https://img.mobilelegends.com/group1/M00/00/07/rB_-LVpDtGqAYtkmAAB3LMQyNAE1871256'),
	(46, 'Lapu-Lapu', 62, 78, 50, 50, 'https://img.mobilelegends.com/group1/M00/00/07/rB_-LVpDtFOALpMsAABzqI8HHNc3695902'),
	(47, 'Aurora', 90, 45, 40, 60, 'https://img.mobilelegends.com/group1/M00/00/07/rB_-LVpDtDuAWUBtAACXl6J3H8w0649495'),
	(48, 'Hilda', 52, 58, 85, 40, 'https://img.mobilelegends.com/group1/M00/00/07/rB_-LVpDtCaAe1FhAABuf7v7jsA9554466'),
	(49, 'Estes', 68, 50, 47, 45, 'https://img.mobilelegends.com/group1/M00/00/07/rB_-LVpDtAuAY9KjAAB9goieF3c7312538'),
	(50, 'Cyclops', 90, 45, 40, 60, 'https://img.mobilelegends.com/group1/M00/00/07/rB_-LVpDs_WAMLPgAABtLD26bHw2740609'),
	(51, 'Johnson', 60, 39, 92, 55, 'https://img.mobilelegends.com/group1/M00/00/07/rB_-LVpDs-GAEphlAAB1QGHzLdM0042563'),
	(52, 'Moskov', 42, 95, 25, 72, 'https://img.mobilelegends.com/group1/M00/00/07/rB_-LVpDs8WAMApUAACHnMnJslA1013106'),
	(53, 'Yi Sun-shin', 75, 79, 46, 60, 'https://img.mobilelegends.com/group1/M00/00/06/rB_-LVpDs6-AfuBvAAB1hMo4n8o5446181'),
	(54, 'Ruby', 65, 45, 78, 70, 'https://img.mobilelegends.com/group1/M00/00/06/rB_-LVpDs5qAaIc-AACNvDUV_WM2807909'),
	(55, 'Alpha', 64, 78, 72, 73, 'https://img.mobilelegends.com/group1/M00/00/06/rB_-LVpDs4CAapSFAAB_TNxgJfA9096154'),
	(56, 'Sun', 47, 75, 70, 42, 'https://img.mobilelegends.com/group1/M00/00/06/rB_-LVpDs2eAKcytAAByEYLkYUY5707478'),
	(57, 'Chou', 52, 82, 78, 64, 'https://img.mobilelegends.com/group1/M00/00/06/rB_-LVpDs1OAe4Y7AAB6sQs4tFo8648682'),
	(58, 'Kagura', 92, 43, 60, 88, 'https://img.mobilelegends.com/group1/M00/00/06/rB_-LVpDsz2AB4wRAAB0eyxfinQ8017109'),
	(59, 'Natalia', 43, 94, 55, 54, 'https://img.mobilelegends.com/group1/M00/00/06/rB_-LVpDsw-AINbmAAB-0TAQLCg2171948'),
	(60, 'Gord', 90, 50, 45, 65, 'https://img.mobilelegends.com/group1/M00/00/06/rB_-LVpDsu2AJfRrAABgxpIyalo4841227'),
	(61, 'Freya', 37, 80, 70, 40, 'https://img.mobilelegends.com/group1/M00/00/06/rB_-LVpDsteATkRJAABzJhxL5Uw5256353'),
	(62, 'Hayabusa', 50, 87, 62, 82, 'https://img.mobilelegends.com/group1/M00/00/06/rB_-LVpDsp6AVrh5AAB2hTL01GM4060727'),
	(63, 'Lolita', 75, 52, 83, 50, 'https://img.mobilelegends.com/group1/M00/00/06/rB_-LVpDsoCAXgcgAAHFUeM_nHE7881836'),
	(64, 'Minotaur', 53, 64, 90, 30, 'https://img.mobilelegends.com/group1/M00/00/06/rB_-LVpDsmyAB2hQAABitrngbf44367568'),
	(65, 'Layla', 62, 95, 18, 25, 'https://img.mobilelegends.com/group1/M00/00/06/rB_-LVpDsk-AEWcBAAFn6UR1Ys87821010'),
	(66, 'Fanny', 50, 85, 60, 100, 'https://img.mobilelegends.com/group1/M00/00/06/rB_-LVpDsgmAYjdvAAFq8Ufvk9M8345030'),
	(67, 'Zilong', 40, 80, 70, 50, 'https://img.mobilelegends.com/group1/M00/00/06/rB_-LVpDseqAcxGXAAGMLKITciY3277840'),
	(68, 'Eudora', 90, 50, 43, 40, 'https://img.mobilelegends.com/group1/M00/00/06/rB_-LVpCPwGAB7zrAAB1dQ0ZohA9753079'),
	(69, 'Rafaela', 75, 40, 52, 34, 'https://img.mobilelegends.com/group1/M00/00/06/rB_-LVpCPu2AZVNaAABxldTawik9737962'),
	(70, 'Clint', 59, 86, 42, 45, 'https://img.mobilelegends.com/group1/M00/00/06/rB_-LVpCPtuAc4byAABzWSCVofo2919295'),
	(71, 'Bruno', 68, 90, 42, 46, 'https://img.mobilelegends.com/group1/M00/00/06/rB_-LVpCPl6AJQnmAAB9dxSBBR45619718'),
	(72, 'Bane', 48, 65, 70, 55, 'https://img.mobilelegends.com/group1/M00/00/01/Cq2Ixlpy3ESAL5xSAAB9Jv8Yf201820471'),
	(73, 'Franco', 50, 60, 80, 60, 'https://img.mobilelegends.com/group1/M00/00/06/rB_-LVpCPjSARDB-AACIudLuyQo8944658'),
	(74, 'Akai', 55, 65, 90, 45, 'https://img.mobilelegends.com/group1/M00/00/06/rB_-LVpCPg2ADY_FAACGMN-QM900735582'),
	(75, 'Karina', 50, 85, 37, 65, 'https://img.mobilelegends.com/group1/M00/00/06/rB_-LVpCPfOAYyyeAAB4xxT1irM2117637'),
	(76, 'Alucard', 50, 87, 50, 45, 'https://img.mobilelegends.com/group1/M00/00/06/rB_-LVpCPdOAT5GKAACKKsGSRDE6559830'),
	(77, 'Tigreal', 62, 34, 90, 25, 'https://img.mobilelegends.com/group1/M00/00/06/rB_-LVpCPZqAP-rOAACPsuXXZMg0097128'),
	(78, 'Nana', 80, 50, 50, 40, 'https://img.mobilelegends.com/group1/M00/00/06/rB_-LVpCHQqAQt-pAACVpimQmbk4797986'),
	(79, 'Alice', 75, 49, 70, 67, 'https://img.mobilelegends.com/group1/M00/00/06/rB_-LVpCHBmAaTZsAACMF8f2yX03838673'),
	(80, 'Saber', 50, 87, 50, 62, 'https://img.mobilelegends.com/group1/M00/00/06/rB_-LVpCG1eAR_AeAAHVwc-d_TY7731883'),
	(81, 'Balmond', 40, 68, 80, 30, 'https://img.mobilelegends.com/group1/M00/00/06/rB_-LVpAwAaAPTfEAAG0FYO4cHo4453688'),
	(82, 'Miya', 62, 95, 42, 25, 'https://img.mobilelegends.com/group1/M00/00/06/rB_-LVpAyOqAcoYgAAHhFjl5Ba05533979');
/*!40000 ALTER TABLE `hero` ENABLE KEYS */;

-- Dumping structure for table lenlegacy.herorole
CREATE TABLE IF NOT EXISTS `herorole` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `heroid` int(11) DEFAULT NULL,
  `roleid` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `herorole_idx` (`heroid`),
  KEY `rolerole_idx` (`roleid`),
  CONSTRAINT `herorole` FOREIGN KEY (`heroid`) REFERENCES `hero` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `rolerole` FOREIGN KEY (`roleid`) REFERENCES `role` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Dumping data for table lenlegacy.herorole: ~0 rows (approximately)
/*!40000 ALTER TABLE `herorole` DISABLE KEYS */;
/*!40000 ALTER TABLE `herorole` ENABLE KEYS */;

-- Dumping structure for table lenlegacy.migration
CREATE TABLE IF NOT EXISTS `migration` (
  `version` varchar(180) NOT NULL,
  `apply_time` int(11) DEFAULT NULL,
  PRIMARY KEY (`version`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Dumping data for table lenlegacy.migration: ~2 rows (approximately)
/*!40000 ALTER TABLE `migration` DISABLE KEYS */;
INSERT INTO `migration` (`version`, `apply_time`) VALUES
	('m000000_000000_base', 1560917655),
	('m130524_201442_init', 1560917666),
	('m190124_110200_add_verification_token_column_to_user_table', 1560917671);
/*!40000 ALTER TABLE `migration` ENABLE KEYS */;

-- Dumping structure for table lenlegacy.player
CREATE TABLE IF NOT EXISTS `player` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(150) NOT NULL,
  `nickname` varchar(150) NOT NULL,
  `tierid` int(11) DEFAULT NULL,
  `status` varchar(45) DEFAULT NULL,
  `image` varchar(200) DEFAULT NULL,
  `gameid` varchar(20) NOT NULL,
  `nohp` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `tierid_idx` (`tierid`),
  CONSTRAINT `tierid` FOREIGN KEY (`tierid`) REFERENCES `tier` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;

-- Dumping data for table lenlegacy.player: ~10 rows (approximately)
/*!40000 ALTER TABLE `player` DISABLE KEYS */;
INSERT INTO `player` (`id`, `name`, `nickname`, `tierid`, `status`, `image`, `gameid`, `nohp`) VALUES
	(1, 'Andi Yuliandi', 'SNiV - semar26', 7, 'A', '', '21414331532', '082219154532'),
	(2, 'Rizki', 'EveZe', 6, 'A', NULL, '21414331532', NULL),
	(3, 'Ferdi', 'Zolf', 5, 'A', NULL, '21414331532', NULL),
	(4, 'Luthfi', 'woodstock82', 6, 'A', NULL, '21414331532', NULL),
	(5, 'Nugraha', 'SNiV - NSF', 6, 'A', NULL, '21414331532', NULL),
	(6, 'Jajat', 'JJTSML', 6, 'A', NULL, '21414331532', NULL),
	(7, 'Alvi', 'alvi48', 5, 'A', NULL, '21414331532', NULL),
	(8, 'Yoga', 'SNiV - Alfatih', 6, 'A', NULL, '21414331532', NULL),
	(9, 'Ryan', 'SNiV - 144RyN', 7, 'A', NULL, '21414331532', NULL),
	(10, 'Arif', 'barbatos', 5, 'A', '', '21414331532', '');
/*!40000 ALTER TABLE `player` ENABLE KEYS */;

-- Dumping structure for table lenlegacy.role
CREATE TABLE IF NOT EXISTS `role` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `rolename` varchar(45) NOT NULL,
  `recordstatus` varchar(45) NOT NULL DEFAULT 'A',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

-- Dumping data for table lenlegacy.role: ~6 rows (approximately)
/*!40000 ALTER TABLE `role` DISABLE KEYS */;
INSERT INTO `role` (`id`, `rolename`, `recordstatus`) VALUES
	(1, 'Assassin', 'A'),
	(2, 'Tank', 'A'),
	(3, 'Fighter', 'A'),
	(4, 'Mage', 'A'),
	(5, 'Marksman', 'A'),
	(6, 'Support', 'A');
/*!40000 ALTER TABLE `role` ENABLE KEYS */;

-- Dumping structure for table lenlegacy.season
CREATE TABLE IF NOT EXISTS `season` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `league` varchar(100) DEFAULT NULL,
  `seasonname` varchar(45) NOT NULL,
  `tglmulai` date DEFAULT NULL,
  `tglselesai` date DEFAULT NULL,
  `jumlahpeserta` int(11) DEFAULT NULL,
  `status` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

-- Dumping data for table lenlegacy.season: ~1 rows (approximately)
/*!40000 ALTER TABLE `season` DISABLE KEYS */;
INSERT INTO `season` (`id`, `league`, `seasonname`, `tglmulai`, `tglselesai`, `jumlahpeserta`, `status`) VALUES
	(1, 'Legacy Mobile Legend League', 'Season 2', '2019-07-01', '2019-07-31', 20, 'A');
/*!40000 ALTER TABLE `season` ENABLE KEYS */;

-- Dumping structure for table lenlegacy.tier
CREATE TABLE IF NOT EXISTS `tier` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tiername` varchar(45) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

-- Dumping data for table lenlegacy.tier: ~7 rows (approximately)
/*!40000 ALTER TABLE `tier` DISABLE KEYS */;
INSERT INTO `tier` (`id`, `tiername`) VALUES
	(1, 'Warrior'),
	(2, 'Elite'),
	(3, 'Master'),
	(4, 'Grand Master'),
	(5, 'Epic'),
	(6, 'Legend'),
	(7, 'Mythic');
/*!40000 ALTER TABLE `tier` ENABLE KEYS */;

-- Dumping structure for table lenlegacy.user
CREATE TABLE IF NOT EXISTS `user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `auth_key` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `password_hash` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `password_reset_token` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `status` smallint(6) NOT NULL DEFAULT '10',
  `created_at` int(11) NOT NULL,
  `updated_at` int(11) NOT NULL,
  `verification_token` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  UNIQUE KEY `email` (`email`),
  UNIQUE KEY `password_reset_token` (`password_reset_token`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- Dumping data for table lenlegacy.user: ~2 rows (approximately)
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` (`id`, `username`, `auth_key`, `password_hash`, `password_reset_token`, `email`, `status`, `created_at`, `updated_at`, `verification_token`) VALUES
	(1, 'andiyuliandi26', 'AtLAJnVTxmASGkBHazl5Cv8gnzVoHLAB', '$2y$13$lVHrT8fTq/4ZNuwRlDXgiObjYrlMTOJyW9KQ6OBGNkiqDnhMNbZVu', NULL, 'andi.sugiarto@len.co.id', 10, 1560917947, 1560917947, 'c8TMeLVAEfA0ZeWa1GySWc-JO6TJODld_1560917947'),
	(2, 'nugraha.saeful', 'WsZHfi1u9WgGYacy3M2zhHgWQiDY5wD1', '$2y$13$CRTAdmzhEe5YfAmN5Ug.qe.jPEIuRlgVqUAfeiQRF1KMQTgmBdCPC', NULL, 'nugraha.saeful@len.co.id', 10, 1560918085, 1560918085, 'fhsvVpjaKQUprGwdiHB5auOopWDA3vlA_1560918085'),
	(3, 'arif', 'izRvpYTNGJne-VMGgtEVe5pAsWQSjqlf', '$2y$13$cnXmKT1IFZUjb//k1Dg9guCrHZq1R5XIRZyl3VRB0POTo7k3R65Xu', NULL, 'arif@len.co.id', 10, 1560919053, 1560919053, 'lcda3oxk3E5EOxcUBI2Aj5rDrnlzdapd_1560919053');
/*!40000 ALTER TABLE `user` ENABLE KEYS */;

/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
